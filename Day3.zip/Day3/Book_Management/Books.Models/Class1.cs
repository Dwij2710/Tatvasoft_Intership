﻿namespace Books.Models
{
    public class Class1
    {

    }
}
