﻿namespace Books.Services
{
    public class Class1
    {

    }
}
